import sys
sys.path.append('/home/roahmlab/Mambo_scripts/lib')

import numpy as np
import time
from scipy import interpolate


def interpolate_mocap_and_cmd(t_queue, t_have, cmd_have):
# interpolate the commands by the machine time by Zero-Order Hold
# t_queue is the interpolated machine time
# assume t_queue is 1-D numpy array, and the output is 2-D numpy array
# time before the first timestamp, commands are zeros
# time after the last timestamp, commands are the last ones.

    boundary = (np.zeros(4), cmd_have[:, -1])
    f = interpolate.interp1d(t_have, cmd_have, kind='zero', bounds_error=False, fill_value=boundary)
    cmd_queue = f(t_queue)
    return cmd_queue


if __name__ == '__main__':
    t_have = np.array([0, 2, 4, 6, 8, 10])
    print("t_have")
    print(t_have)
    cmd_have = np.array([[0,20,40,60,80,100],[0,-20,-40,-60,-80,-100],[0,10,20,30,40,50],[0,-10,-20,-30,-40,-50]])
    print("cmd_have")
    print(cmd_have)

    t_queue = np.array([-1, 0, 0.5, 1, 1.5, 2, 2.5, 5, 5.5, 8.9, 10, 11])
    print("t_queue")
    print(t_queue)

    cmd_queue = interpolate_mocap_and_cmd(t_queue, t_have, cmd_have)

    print("cmd_queue")
    print(cmd_queue)
