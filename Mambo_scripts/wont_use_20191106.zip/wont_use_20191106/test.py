import sys
sys.path.append('/home/roahmlab/Mambo_scripts/lib')

import socket
import numpy as np
import time
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

import helper_function as hf


if __name__ == '__main__':
#######################################################

#######################################################
    HOST = '127.0.0.1'  # Standard loopback interface address (localhost)
    PORT = 9000        # Port to listen on (non-privileged ports are > 1023)

    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Connect the socket to the port where the server is listening
    server_address = (HOST, PORT)
    print("connecting to", server_address)
    sock.connect(server_address)

#######################################################
    # define some variables
    Directory_sysid = '/home/roahmlab/Mambo_scripts/low_level_controller/sysid_data/'
    Directory_traj = '/home/roahmlab/Mambo_scripts/low_level_controller/traj_lib/'
    Directory_delete = '/home/roahmlab/Mambo_scripts/low_level_controller/traj_lib/*'

    tilt_max = radians(25.0) # in degrees to radians
    vz_max = 2.0 # in m/s
    yaw_rate_max = 3.14 # in radians/sec

    # remember: in mocap system, euler angles depends on the fixed global axes,
    # but for drone commands, euler angles depends on the current orientation
    # need to stablize yaw very quickly

    # PID terms
    P_now = np.array([[0.0], [0.0], [0.0], [0.0]])

    t_look_ahead = 0.2 # seconds

    dt_traj = 0.10
    yaw_prev = 0.5 # non-zero initial value
    posi_pre = np.array([[0.0], [0.0], [0.0]])
    velo_now = np.array([[0.0], [0.0], [0.0]])
    dt = dt_traj
    t_now = 0.0
    hover_flag = True
    hover_flag_pre = True

    states_history = 0.0
    time_plot = []
    pv_plot = 0.0
    angle_and_cmd_plot = 0.0

    hf.remove_traj_ref_lib(Directory_delete)

#######################################################

        idx = 0

# Remember to change the total time!!!!!!!!!!!!!!!!!

        while t_now < t_stop:
            t0 = time.time()

            # get states
            # notice that the current function works only for one rigid body
            posi_now, ori_quat, mambo = hf.get_states_mocap(sock, mambo)
            # compute some variables
            posi_now, posi_pre, velo_now, Rot_Mat, yaw_now, pitch_now, roll_now, yaw_prev, velo_body, yaw_rate = \
            hf.compute_states(posi_now, posi_pre, ori_quat, yaw_prev, dt)

            traj_ref, T, hover_flag = hf.update_csv(Directory_traj)

            if not hover_flag:
                #if hover_flag != hover_flag_pre:
                if (hover_flag == False) & (hover_flag_pre == True):
                    t_start = t0
                    idx = 0

                t_now = t0 - t_start
                print("Total Time")
                print(t_now)

                if True:
                    # load the current and the next desired points
                    # 2-D numpy array, 6 by 1, px, py, pz, vx, vy, vz
                    point_ref_0 = hf.interpolate_traj(t_now, T, traj_ref)
                    point_ref_1 = hf.interpolate_traj(t_now + dt_traj + t_look_ahead, T, traj_ref)

                    P_now, pitch_cmd, roll_cmd, vz_cmd, yaw_rate_cmd = \
                        hf.LLC_PD_sin_fast(idx, posi_now, point_ref_0, point_ref_1, yaw_now, yaw_des, Rot_Mat, P_now, velo_body, yaw_rate, vz_max, dt)

                    # record
                    states_history = hf.record_sysid(idx, states_history, t_now, posi_now, yaw_now, pitch_now, roll_now, yaw_rate_cmd, pitch_cmd, roll_cmd, vz_cmd)
                    # p, v, yaw, pitch, roll, yaw, pitch, roll, vz
                    time_plot, pv_plot, angle_and_cmd_plot = hf.record_states_plot(idx, t_now, posi_now, velo_now, yaw_now, pitch_now, roll_now, yaw_rate_cmd, pitch_cmd, roll_cmd, vz_cmd, time_plot, pv_plot, angle_and_cmd_plot)
                    # send commands
                    #mambo.smart_sleep(dt_traj)
                    mambo.fly_direct(roll_cmd, pitch_cmd, yaw_rate_cmd, vz_cmd, dt_traj)
                else:
                    mambo.fly_direct(0.0, 0.0, 0.0, 0.0, dt_traj)
                
            else:
                print("Haven't generated csv file in MATLAB")
                mambo.fly_direct(0.0, 0.0, 0.0, 0.0, dt_traj)

            hover_flag_pre = hover_flag
            t1 = time.time()
            dt = t1 - t0
            print("time interval for fly command")
            print(dt)
            print("current time")
            print(t_now)
            idx += 1


        mambo.fly_direct(0, 0, 0, 0, 1.0)
    



        hf.save_csv_sysid(states_history, Directory_sysid)

        battery_1 = mambo.sensors.battery
        print("The battery percentage is ", battery_1)

        battery_used = battery_0 - battery_1
        print("The used battery percentage is", battery_used)
