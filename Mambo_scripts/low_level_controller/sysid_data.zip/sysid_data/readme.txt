The format for csv file is:

time_trajectory (second)
px (meter)
py (meter)
pz (meter)
yaw (radian)
pitch (radian)
roll (radian)
yaw_rate_command (percentage [-100, 100])
pitch_cmd (percentage [-100, 100])
roll_cmd (percentage [-100, 100])
vz_cmd (percentage [-100, 100])

